/// Re-export errors
pub use kaspa_mining_errors::block_template::*;
