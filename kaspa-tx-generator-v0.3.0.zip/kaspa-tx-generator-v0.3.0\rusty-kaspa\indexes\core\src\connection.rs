use crate::notification::Notification;

pub type IndexChannelConnection = kaspa_notify::connection::ChannelConnection<Notification>;
