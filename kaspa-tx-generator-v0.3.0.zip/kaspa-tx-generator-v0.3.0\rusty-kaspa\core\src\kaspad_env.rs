pub fn version() -> &'static str {
    env!("CARGO_PKG_VERSION")
}

pub fn name() -> &'static str {
    "kaspad"
}
