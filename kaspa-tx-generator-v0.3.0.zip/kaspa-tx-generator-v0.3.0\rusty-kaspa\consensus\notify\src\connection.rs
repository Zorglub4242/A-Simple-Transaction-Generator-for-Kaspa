use crate::notification::Notification;

pub type ConsensusChannelConnection = kaspa_notify::connection::ChannelConnection<Notification>;
