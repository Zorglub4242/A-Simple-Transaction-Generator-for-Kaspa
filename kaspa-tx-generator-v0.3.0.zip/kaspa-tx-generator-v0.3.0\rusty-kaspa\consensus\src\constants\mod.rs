// Re-exports constants from consensus core for internal crate usage
pub use kaspa_consensus_core::config::constants::*;
pub(crate) use kaspa_consensus_core::constants::*;
