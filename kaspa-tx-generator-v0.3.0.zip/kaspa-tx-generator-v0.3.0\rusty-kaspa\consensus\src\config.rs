// Re-exports from consensus core for internal crate usage
pub use kaspa_consensus_core::config::*;
