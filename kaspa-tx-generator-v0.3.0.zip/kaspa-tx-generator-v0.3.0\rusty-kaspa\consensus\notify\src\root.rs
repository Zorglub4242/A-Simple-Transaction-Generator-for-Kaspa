use crate::notification::Notification;
use kaspa_notify::root::Root;

pub type ConsensusNotificationRoot = Root<Notification>;
