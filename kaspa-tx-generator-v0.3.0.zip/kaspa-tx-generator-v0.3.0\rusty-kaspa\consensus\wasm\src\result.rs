pub type Result<T, E = super::error::Error> = std::result::Result<T, E>;
