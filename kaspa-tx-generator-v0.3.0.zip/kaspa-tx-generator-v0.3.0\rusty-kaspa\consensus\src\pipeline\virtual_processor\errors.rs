//! Re-exports pruning-related errors from consensus core for internal crate usage
pub(crate) use kaspa_consensus_core::errors::pruning::*;
