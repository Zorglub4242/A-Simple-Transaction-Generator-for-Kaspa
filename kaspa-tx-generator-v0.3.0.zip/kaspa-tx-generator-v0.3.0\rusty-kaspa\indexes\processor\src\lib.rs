pub mod errors;
pub mod processor;
pub mod service;

const IDENT: &str = "index-processor";
